<?php

echo'{
    "r":[
	        { "headingkey": "Live - CNN.com",
	        "headinglink": "http://www.cnn.com/tv/watch/live-2",
	        "subheadingkey": "http://www.cnn.com/tv/watch/live-2",
	        "subheadinglink": "http://www.cnn.com/tv/watch/live-2",
	        "para":"Live TV · Digital Studios · CNN Films · HLN · TV Schedule · TV Shows A-Z · How To Watch VR · Archives · More… Photos · Longform · Investigations · iReport ..."
	        },
	        { "headingkey": "Watch Live TV - CNNgo - CNN.com",
	        "headinglink": "http://www.cnn.com/specials/about-live-tv",
	        "subheadingkey": "http://www.cnn.com/specials/about-live-tv",
	        "subheadinglink": "http://www.cnn.com/specials/about-live-tv",
	        "para":"Click Watch Live TV on CNN.com then select your TV service provider. ... Watch live news coverage and your favorite shows on demand. At home or on the go!"
	        },
	        { "headingkey": "CNN News18 Live TV | Breaking News | Live News ... - News18.com",
	        "headinglink": "http://www.news18.com/livetv/",
	        "subheadingkey": "http://www.news18.com/livetv/",
	        "subheadinglink": "http://www.news18.com/livetv/",
	        "para":"Watch CNN News18 live tv online for breaking news only at News18.com. CNN News18 is India\'s most awarded English news channel that provides all ..."
	        },
	        { "headingkey": "Watch CNN News USA Live Streaming - CNN Live Stream",
	        "headinglink": "http://www.livenewson.com/",
	        "subheadingkey": "http://www.livenewson.com/",
	        "subheadinglink": "http://www.livenewson.com/",
	        "para":"Watch CNN News Live Streaming Directly from United States with High definition video quality for free. Get the Latest news and updates on CNN live stream."
	        },
	        { "headingkey": "CNNLivestreams - YouTube",
	        "headinglink": "https://www.youtube.com/user/CNNLivestreams",
	        "subheadingkey": "https://www.youtube.com/user/CNNLivestreams",
	        "subheadinglink": "https://www.youtube.com/user/CNNLivestreams",
	        "para":"CNN Live offers live streaming of important news events and CNN G+ chats."
	        },
	        { "headingkey": "KCNN live stream News 24/7 - YouTube",
	        "headinglink": "https://www.youtube.com/channel/UCD8Jj9EGtcaiD-QNGcuhYgw",
	        "subheadingkey": "https://www.youtube.com/channel/UCD8Jj9EGtcaiD-QNGcuhYgw",
	        "subheadinglink": "https://www.youtube.com/channel/UCD8Jj9EGtcaiD-QNGcuhYgw",
	        "para":"LIVE CNN CNN live stream News 24/7 Donald Trump Inauguration Live | CNN News Live | Donald Trump Live News presidental Inauguration live stream The ...."
	        },
	        { "headingkey": "Watch CNN International Live TV from USA - Online TV channel",
	        "headinglink": "http://www.freeintertv.com/view/id-200",
	        "subheadingkey": "http://www.freeintertv.com/view/id-200",
	        "subheadinglink": "http://www.freeintertv.com/view/id-200",
	        "para":"Live TV stream of CNN International broadcasting from USA. Channel description of CNN International: News TV channel."
	        },
	        {  "headingkey": "STREAMFARE - CNN LIVE STREAM",
	        "headinglink": "http://streamfare.com/cnn.html",
	        "subheadingkey": "http://streamfare.com/cnn.html",
	        "subheadinglink": "http://streamfare.com/cnn.html",
	        "para":"bitly blogger blogmarks buzz delicious digg diigo dzone facebook google linkedin live myspace netvibes newsvine reddit stumbleupon tipd tumblr twitter ..."
	        },
	        { "headingkey": "Top News Headlines CNN Live Stream - Live News Cloud Stream",
	        "headinglink": "http://www.livenewschat.eu/top/",
	        "subheadingkey": "http://www.livenewschat.eu/top/",
	        "subheadinglink": "http://www.livenewschat.eu/top/",
	        "para":"Top News Headlines CNN Live Stream. Watch all of CNN LIVE STREAM Breaking news live here."
	        },
	        { "headingkey": "CNN | The Huffington Post",
	        "headinglink": "http://www.huffingtonpost.com/topic/cnn",
	        "subheadingkey": "http://www.huffingtonpost.com/topic/cnn",
	        "subheadinglink": "http://www.huffingtonpost.com/topic/cnn",
	        "para":"Misleading And Sensational, CNN\'s \'Believer\' Pilot Amounts To \'Fake News\' · Parth Parihar Economics Ph.D. Student and General Secretary, Hindu Students ."
	        }
       ]
    }   
';
?>

