import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component'; //import home components
import { AboutComponent } from './about/about.component'; //import about component
import { ContactComponent } from './contact/contact.component'; //import contact component
import { PublicationsComponent } from './publications/publications.component'; //import publications component
import { ServicesComponent } from './services/services.component'; //import services component
import { LoginComponent } from './login/login.component'; //import login component


const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'publications',component: PublicationsComponent },
  { path: 'services', component: ServicesComponent },
  
  { path: 'login', component: LoginComponent},
  { path: '', component: HomeComponent, pathMatch: 'full'} // redirect to home page on load
];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);
