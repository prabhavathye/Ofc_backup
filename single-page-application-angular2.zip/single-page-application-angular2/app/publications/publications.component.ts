import {Component} from '@angular/core';

@Component({
    selector: 'app-publications',
    template: `<h1>{{welcome}}</h1>`
})
export class PublicationsComponent {
    welcome : string;
    constructor(){
        this.welcome = "Welcome to publication page"
    };
};