import {Component} from '@angular/core';

@Component({
    selector: 'app-services',
    template: `<h1>{{welcome}}</h1>`
})
export class ServicesComponent {
    welcome : string;
    constructor(){
        this.welcome = "Welcome to services page"
    };
};