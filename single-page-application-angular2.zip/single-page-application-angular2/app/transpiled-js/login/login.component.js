"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var http_1 = require('@angular/http');
var LoginComponent = (function () {
    function LoginComponent(fb, http) {
        this.http = http;
        if (localStorage.getItem('jwt')) {
            this.authenticated = true;
            this.profile = JSON.parse(localStorage.getItem('profile'));
        }
        this.loginForm = fb.group({
            'email': [null, forms_1.Validators.required],
            'password': [null, forms_1.Validators.required],
        });
    }
    LoginComponent.prototype.submitForm = function (value) {
        var _this = this;
        var form = {
            'client_id': 'YOUR-AUTH0-CLIENT-ID',
            'username': value.email,
            'password': value.password,
            'connection': 'YOUR-DATABASE-CONNECTION-NAME',
            'grant_type': 'password',
            'scope': 'openid name email'
        };
        this.http.post('https://YOUR-AUTH0-DOMAIN.auth0.com/oauth/ro', form).subscribe(function (res) {
            var data = res.json();
            if (data.id_token) {
                localStorage.setItem('jwt', data.id_token);
                _this.getUserInfo(data);
            }
        });
    };
    LoginComponent.prototype.getUserInfo = function (data) {
        var _this = this;
        var form = {
            'id_token': data.id_token
        };
        this.http.post('https://YOUR-AUTH0-DOMAIN.auth0.com/tokeninfo', form).subscribe(function (res) {
            var data = res.json();
            _this.profile = data;
            localStorage.setItem('profile', JSON.stringify(data));
            _this.authenticated = true;
            _this.loginForm.reset();
        });
    };
    LoginComponent.prototype.logout = function () {
        localStorage.removeItem('jwt');
        localStorage.removeItem('profile');
        this.authenticated = false;
    };
    LoginComponent = __decorate([
        core_1.Component({
            selector: 'app-login',
            template: "\n  <div class=\"jumbotron\" *ngIf=\"!authenticated\">\n    <h2>Login Form</h2>\n    <form [formGroup]=\"loginForm\" (ngSubmit)=\"submitForm(loginForm.value)\">\n      <div class=\"form-group\" [ngClass]=\"{'has-error':!loginForm.controls['email'].valid && loginForm.controls['email'].touched}\">\n        <label>Email:</label>\n        <input class=\"form-control\" type=\"text\" placeholder=\"John@doe.com\" [formControl]=\"loginForm.controls['email']\">\n        <div *ngIf=\"loginForm.controls['email'].hasError('required') && loginForm.controls['email'].touched\" class=\"alert alert-danger\">You must add an email.</div>\n      </div>\n      <div class=\"form-group\" [ngClass]=\"{'has-error':!loginForm.controls['password'].valid && loginForm.controls['password'].touched}\">\n        <label>Password:</label>\n        <input class=\"form-control\" type=\"password\" placeholder=\"Password\" [formControl]=\"loginForm.controls['password']\">\n        <div *ngIf=\"loginForm.controls['password'].hasError('required') && loginForm.controls['password'].touched\" class=\"alert alert-danger\">You must add a password.</div>\n      </div>\n      <div class=\"form-group\">\n        <button type=\"submit\" class=\"btn btn-primary\" [disabled]=\"!loginForm.valid\">Submit</button>\n      </div>\n    </form>\n  </div>\n  <div class=\"jumbotron text-center\" *ngIf=\"authenticated\">\n    <img src=\"{{profile.picture}}\" />\n    <h2>Welcome, {{profile.email}}</h2>\n    <a (click)=\"logout()\">Logout</a>\n  </div>\n  "
        }), 
        __metadata('design:paramtypes', [forms_1.FormBuilder, http_1.Http])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map