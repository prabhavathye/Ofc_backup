"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('./home/home.component'); //import home components
var about_component_1 = require('./about/about.component'); //import about component
var contact_component_1 = require('./contact/contact.component'); //import contact component
var publications_component_1 = require('./publications/publications.component'); //import publications component
var services_component_1 = require('./services/services.component'); //import services component
var login_component_1 = require('./login/login.component'); //import login component
var appRoutes = [
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'about', component: about_component_1.AboutComponent },
    { path: 'contact', component: contact_component_1.ContactComponent },
    { path: 'publications', component: publications_component_1.PublicationsComponent },
    { path: 'services', component: services_component_1.ServicesComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: '', component: home_component_1.HomeComponent, pathMatch: 'full' } // redirect to home page on load
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map