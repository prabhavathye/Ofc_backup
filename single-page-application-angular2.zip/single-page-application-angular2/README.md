# single-page-application-angular2

### Quick Setup
- `$ git clone https://github.com/rahil471/single-page-application-angular2.git`
- Navigate into the directory using command line interface
- `$ npm install`
- `$ npm start`

### Full Tutorial
*Visit* - https://code.ciphertrick.com/2016/07/26/build-single-page-application-angular-2/
