<?php
    namespace Webkul\Hello\Controller\Adminhtml\Csv;
//use Mage;
   //   namespace MyCompany\ExampleAdminNewPage\Controller\Adminhtml\HelloWorld;

      class Index extends \Magento\Backend\App\Action
      {
        /**
        * @var \Magento\Framework\View\Result\PageFactory
        */
        protected $resultPageFactory;

        /**
         * Constructor
         *
         * @param \Magento\Backend\App\Action\Context $context
         * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
         */
        public function __construct(
            \Magento\Backend\App\Action\Context $context,
            \Magento\Framework\View\Result\PageFactory $resultPageFactory
        ) {
             parent::__construct($context);
             $this->resultPageFactory = $resultPageFactory;
        }

        /**
         * Load the page defined in view/adminhtml/layout/exampleadminnewpage_helloworld_index.xml
         *
         * @return \Magento\Framework\View\Result\Page
         */
        public function execute()
        {
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $connection = $objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
            $result1 = $connection->fetchAll("SELECT SUM(total_qty_ordered) as total_qty_ordered ,DATE_FORMAT(created_at,'%Y-%m-%d') as created_at  FROM sales_order WHERE status!='canceled' GROUP BY DATE_FORMAT(created_at,'%Y-%m-%d')");
           
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $connection = $objectManager->get('Magento\Framework\App\ResourceConnection')->getConnection('\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION'); 
            $result2 = $connection->fetchAll("SELECT COUNT(entity_id) as entity_id,DATE_FORMAT(created_at,'%Y-%m-%d') as created_at  FROM sales_order WHERE status!='canceled' GROUP BY DATE_FORMAT(created_at,'%Y-%m-%d')");
           
            $sampleArray[0][]="Date";
            $sampleArray[0][]="Sales";
            foreach ($result1 as $key => $value) {
            $sampleArray[$key+1][]=$value['created_at'];
            $sampleArray[$key+1][]=(int)$value['total_qty_ordered'];
               //$sampleArray[$key+1][]='green';
            }
            $sampleArray1[0][]="Date";
            $sampleArray1[0][]="Sales";
            foreach ($result2 as $key => $value) {
            $sampleArray1[$key+1][]=$value['created_at'];
            $sampleArray1[$key+1][]=(int)$value['entity_id'];
            }
header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=file.csv");
$output = fopen("php://output", "w");
foreach ($sampleArray as $row)
fputcsv($output, $row); // here you can change delimiter/enclosure
fclose($output);

$output1 = fopen("php://output", "w");
foreach($sampleArray1 as $row1)
  fputcsv($output1, $row1);
  fclose($output1);

//outputCSV($sampleArray);
        }
      }

?>
